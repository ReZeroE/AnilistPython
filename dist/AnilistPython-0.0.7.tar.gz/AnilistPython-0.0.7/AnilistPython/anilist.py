'''
File primarily used for bots. Currently Under Development
'''