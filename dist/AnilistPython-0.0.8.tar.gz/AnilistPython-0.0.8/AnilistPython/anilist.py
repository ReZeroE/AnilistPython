'''
File reserved for bot functions. Currently Under Development
'''