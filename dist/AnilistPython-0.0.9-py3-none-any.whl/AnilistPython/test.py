'''
Test Cases

from __init__ import Anilist
instance = Anilist()
'''

