class AnilistPythonInfo:
    '''
    Built-in help module. Currently Under Development
    '''
    def help(self):
        print("\nFor the full documentation, please visit <https://github.com/ReZeroE/AnilistPython>.")