
from datetime import datetime

class ReportLog:

    '''
    Reports log files for improvement. Currently under development.
    '''

    def __init__(self):
        pass

    def report_log_file(self):
        pass



